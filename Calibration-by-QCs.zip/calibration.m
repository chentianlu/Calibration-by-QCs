%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Peak data calibration and integration                  %
%  Version 1.0                                            %
%  Tianlu Chen 2013-05-20                                 %
%  All rights reserved 2012 @ Wei Jia Group (Metabolomics)%
%  chentianlu@sjtu.edu.cn                                 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function varargout = calibration(varargin)
% CALIBRATION M-file for calibration.fig
%      CALIBRATION, by itself, creates a new CALIBRATION or raises the existing
%      singleton*.
%
%      H = CALIBRATION returns the handle to a new CALIBRATION or the handle to
%      the existing singleton*.
%
%      CALIBRATION('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in CALIBRATION.M with the given input arguments.
%
%      CALIBRATION('Property','Value',...) creates a new CALIBRATION or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before calibration_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to calibration_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help calibration

% Last Modified by GUIDE v2.5 21-May-2013 15:51:30

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @calibration_OpeningFcn, ...
                   'gui_OutputFcn',  @calibration_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before calibration is made visible.
function calibration_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to calibration (see VARARGIN)

% Choose default command line output for calibration
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes calibration wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = calibration_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1

type=get(handles.popupmenu1,'Value');
dim=get(handles.popupmenu2,'Value');
load raw; % data and datatxt
load qclist; % qc_list, num_qc, and index
[row,col]=size(data);
% num_qc=get(handles.edit1,'string');
% num_qc1=str2num(num_qc);
col_sample=str2num(get(handles.edit5,'string'));
sample=data(:,1:col_sample);
qc=data(:,(col_sample+index));
data1=[sample qc];
cla;
% qc_list=datatxt(1,(size(datatxt,2)-num_qc1)+1):end);
% sample_qc_list=datatxt(1,2:end);
% sample_list=datatxt(1,2:col_sample);
% set(handles.listbox1,'string',qc_list');
if (type==1) % both sample and qc
    if (dim==1)% 2 dimention
        [T,P]=pca(data1',2);
        hold(handles.axes1,'on');
        plot(handles.axes1,T(1:col_sample,1),T(1:col_sample,2),'bs','markersize',8);% sample
        hold on
        plot(handles.axes1,T((col_sample+1):end,1),T((col_sample+1):end,2),'ro','markersize',8);   % qc
        xlabel('t1');
        ylabel('t2');
        hold(handles.axes1,'off');
    elseif(dim==2)% 1 dimention
        [T,P]=pca(data1',1);
        hold(handles.axes1,'on');
        plot(handles.axes1,1:col_sample,T(1:col_sample,1),'bs','markersize',8);% sample
        hold on
        plot(handles.axes1,(col_sample+1):size(T,1),T((col_sample+1):end,1),'ro','markersize',8);   % qc
        hold on
        s=std(T)*3+mean(T);
        ss=mean(T)-3*std(T);
        line(1:col,s,'Color','r','LineWidth',50);
        line(1:col,ss,'Color','r','LineWidth',50);
        xlabel('index');
        ylabel('t1');
        hold(handles.axes1,'off');
    end
elseif (type ==2)%qc only
    if (dim==1)% 2 dimention
        [T_qc,P_qc]=pca(qc',2);
        hold(handles.axes1,'on');
        plot(handles.axes1,T_qc(:,1),T_qc(:,2),'ro','markersize',8);   % qc
        xlabel('t1');
        ylabel('t2');
        hold(handles.axes1,'off');
    elseif(dim==2)% 1 dimention
        [T_qc,P_qc]=pca(qc',1);
        hold(handles.axes1,'on');
        plot(handles.axes1,1:num_qc,T_qc(:,1),'ro','markersize',8);   % qc
        hold on
        s=std(T_qc)*3+mean(T_qc);
        ss=mean(T_qc)-3*std(T_qc);
        line(1:num_qc,s,'Color','r','LineWidth',50);
        line(1:num_qc,ss,'Color','r','LineWidth',50);
        xlabel('index');
        ylabel('t1');
        hold(handles.axes1,'off');
    end
end

    





% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu2.
function popupmenu2_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu2


type=get(handles.popupmenu1,'Value');
dim=get(handles.popupmenu2,'Value');
load raw; % data and datatxt
load qclist; % qc_list, num_qc, and index
[row,col]=size(data);
% num_qc=get(handles.edit1,'string');
% num_qc1=str2num(num_qc);
col_sample=str2num(get(handles.edit5,'string'));
sample=data(:,1:col_sample);
qc=data(:,(col_sample+index));
data1=[sample qc];
cla;
% qc_list=datatxt(1,(size(datatxt,2)-num_qc1)+1):end);
% sample_qc_list=datatxt(1,2:end);
% sample_list=datatxt(1,2:col_sample);
% set(handles.listbox1,'string',qc_list');
if (type==1) % both sample and qc
    if (dim==1)% 2 dimention
        [T,P]=pca(data1',2);
        hold(handles.axes1,'on');
        plot(handles.axes1,T(1:col_sample,1),T(1:col_sample,2),'bs','markersize',8);% sample
        hold on
        plot(handles.axes1,T((col_sample+1):end,1),T((col_sample+1):end,2),'ro','markersize',8);   % qc
        xlabel('t1');
        ylabel('t2');
        hold(handles.axes1,'off');
    elseif(dim==2)% 1 dimention
        [T,P]=pca(data1',1);
        hold(handles.axes1,'on');
        plot(handles.axes1,1:col_sample,T(1:col_sample,1),'bs','markersize',8);% sample
        hold on
        plot(handles.axes1,(col_sample+1):size(T,1),T((col_sample+1):end,1),'ro','markersize',8);   % qc
        hold on
        s=std(T)*3+mean(T);
        ss=mean(T)-3*std(T);
        line(1:col,s,'Color','r','LineWidth',50);
        line(1:col,ss,'Color','r','LineWidth',50);
        xlabel('index');
        ylabel('t1');        
        hold(handles.axes1,'off');
    end
elseif (type ==2)%qc only
    if (dim==1)% 2 dimention
        [T_qc,P_qc]=pca(qc',2);
        hold(handles.axes1,'on');
        plot(handles.axes1,T_qc(:,1),T_qc(:,2),'ro','markersize',8);   % qc
        xlabel('t1');
        ylabel('t2');
        hold(handles.axes1,'off');
    elseif(dim==2)% 1 dimention
        [T_qc,P_qc]=pca(qc',1);
        hold(handles.axes1,'on');
        plot(handles.axes1,1:num_qc,T_qc(:,1),'ro','markersize',8);   % qc
        hold on
        s=std(T_qc)*3+mean(T_qc);
        ss=mean(T_qc)-3*std(T_qc);
        line(1:0.1:num_qc,s,'Color','r','LineWidth',50);
        line(1:0.1:num_qc,ss,'Color','r','LineWidth',50);
        xlabel('index');
        ylabel('t1');
        hold(handles.axes1,'off');
    end
end

    

% --- Executes during object creation, after setting all properties.
function popupmenu2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in listbox1.
function listbox1_Callback(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns listbox1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox1

value=get(handles.listbox1,'value');

% redraw the plot in order to clear historital hh
type=get(handles.popupmenu1,'Value');
dim=get(handles.popupmenu2,'Value');
load raw; % data and datatxt
load qclist; % qc_list, num_qc, and index
[row,col]=size(data);
col_sample=str2num(get(handles.edit5,'string'));
sample=data(:,1:col_sample);
qc=data(:,(col_sample+index));
data1=[sample qc];
cla;

if (type==1) % both sample and qc
    if (dim==1)% 2 dimention
        [T,P]=pca(data1',2);
        hold(handles.axes1,'on');
        plot(handles.axes1,T(1:col_sample,1),T(1:col_sample,2),'bs','markersize',8);% sample
        hold on
        plot(handles.axes1,T((col_sample+1):end,1),T((col_sample+1):end,2),'ro','markersize',8);   % qc
        xlabel('t1');
        ylabel('t2');
        hold(handles.axes1,'off');
    elseif(dim==2)% 1 dimention
        [T,P]=pca(data1',1);
        hold(handles.axes1,'on');
        plot(handles.axes1,1:col_sample,T(1:col_sample,1),'bs','markersize',8);% sample
        hold on
        plot(handles.axes1,(col_sample+1):size(T,1),T((col_sample+1):end,1),'ro','markersize',8);   % qc
        hold on
        s=std(T)*3+mean(T);
        ss=mean(T)-3*std(T);
        line(1:col,s,'Color','r','LineWidth',50);
        line(1:col,ss,'Color','r','LineWidth',50);
        xlabel('index');
        ylabel('t1');
        hold(handles.axes1,'off');
    end
elseif (type ==2)%qc only
    if (dim==1)% 2 dimention
        [T_qc,P_qc]=pca(qc',2);
        hold(handles.axes1,'on');
        plot(handles.axes1,T_qc(:,1),T_qc(:,2),'ro','markersize',8);   % qc
        xlabel('t1');
        ylabel('t2');
        hold(handles.axes1,'off');
    elseif(dim==2)% 1 dimention
        [T_qc,P_qc]=pca(qc',1);
        hold(handles.axes1,'on');
        plot(handles.axes1,1:num_qc,T_qc(:,1),'ro','markersize',8);   % qc
        hold on
        s=std(T_qc)*3+mean(T_qc);
        ss=mean(T_qc)-3*std(T_qc);
        line(1:0.1:num_qc,s,'Color','r','LineWidth',50);
        line(1:0.1:num_qc,ss,'Color','r','LineWidth',50);
        xlabel('index');
        ylabel('t1');
        hold(handles.axes1,'off');
    end
end

hh=get(handles.axes1,'children');
[change_index,i_index,i_value]=intersect(index,value);% points need to be changed
if(length(i_index)>=1)
    if(type==1) % both sample and qc        
         t1=get(hh(end-1),'XData');% hh(end-1)=qc handel; hh(end)= sample handle; others are for the line
         t2=get(hh(end-1),'YData');
         hold(handles.axes1,'on');
         plot(t1(i_index),t2(i_index),'ko','Markersize',15);
         hold(handles.axes1,'off');
    elseif(type==2) %  qc only
        t1=get(hh(end),'XData');% hh(end)=qc handel;others are for the line
        t2=get(hh(end),'YData');
        hold(handles.axes1,'on');
        plot(t1(i_index),t2(i_index),'ko','Markersize',15);
        hold(handles.axes1,'off');
    end
end


% --- Executes during object creation, after setting all properties.
function listbox1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% % --- Executes on button press in radiobutton1.
% function radiobutton1_Callback(hObject, eventdata, handles)
% % hObject    handle to radiobutton1 (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% 
% % Hint: get(hObject,'Value') returns toggle state of radiobutton1
% 
% 
% % --- Executes on button press in radiobutton2.
% function radiobutton2_Callback(hObject, eventdata, handles)
% % hObject    handle to radiobutton2 (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% 
% % Hint: get(hObject,'Value') returns toggle state of radiobutton2



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[File,Path] = uiputfile({'*.fig';'*.tiff';'*.ai'},'Save the figure to');
% saveas(handles.axes1,[Path,File]);
% saveas(gcf,[Path,File]);
newf = figure('visible','off'); 
axes2 = copyobj(handles.axes1,gcf);
set(axes2,'units','default','position','default');
saveas(gcf,[Path,File]);
delete(newf); 



% --- Executes on button press in checkbox1.
function checkbox1_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox1


% --- Executes on button press in checkbox2.
function checkbox2_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox2


% --- Executes on button press in checkbox3.
function checkbox3_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox3



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton2. default parameters
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.edit1,'string','30');
% set(handles.edit2,'string','10');
set(handles.edit3,'string','4');
set(handles.edit4,'string','30');
set(handles.edit5,'string','40');
set(handles.edit2,'string','30');
set(handles.checkbox1,'value',1);
set(handles.popupmenu3,'value',1);

% --- Executes on button press in pushbutton3. import data
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
waitfor(msgbox('Only one file containing both sample and QC will be loaded.IS(optional)should be placed in the first row.','load data','help'));
[File,Path] = uigetfile({'*.xls';'*.xlsx'},'Select the data file');
% type0=findstr(File, '.xlsx');
% type1=findstr(File, '.xls');
[data,datatxt] = xlsread([Path,File]);
save raw data datatxt;
% set(handles.uipanel1,'visible','on');
set(handles.uipanel6,'visible','on');% parameter setting
% set(handles.uipanel2,'visible','on');%outlier selection
% set(handles.pushbutton4,'visible','on');% run and save result

% --- Executes on button press in pushbutton4. run and save result
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

tic% timing
w = waitbar(0,'Please wait while calibration is in progress......');
    
rawqc_num=str2num(get(handles.edit1,'string'));% raw num of QCs
qc_batch=str2num(get(handles.edit3,'string'));% batch or window size
zero_ratio=str2num(get(handles.edit4,'string'));% delete ratio of zero
sample_num=str2num(get(handles.edit5,'string'));% num of samples
rsd_ratio=str2num(get(handles.edit2,'string'));% delete ratio of RSD
qc_manner=get(handles.popupmenu3,'value');% average manner of qc(1 batch or 2 window)
qc=get(handles.checkbox1,'value');% QC calibration?
is=get(handles.checkbox2,'value');% IS calibration?
zscore=get(handles.checkbox3,'value');% Z score?

load raw;% data and datatxt
load qclist;% qc_list, num_qc, and index

sample=data(:,1:sample_num);
qc_raw=data(:,(sample_num+1):end);
variable=size(sample,1);
datatxt1=cell(variable,1);
compound=size(datatxt,1)-1;
datatxt1(1:compound,1)=datatxt(2:end,1);% compound names
datatxt2=datatxt(1,2:(sample_num+1));% title of samples

waitbar(0.1);

% qc preparation (4 steps)
    % 1. interpolation by average adjacent ones
    % qc_inter is the processed qc data for following steps
[diff,inter]=setdiff(1:rawqc_num,index); 

if(inter)
    qc_inter=qc_raw;
  
    for i=1:length(inter)
      if(inter(i)<index(1))
          qc_inter(:,inter(i))=qc_raw(:,index(1));
          inter=inter(2:end);
      elseif(inter(i)>index(end))
          qc_inter(:,inter(i))=qc_raw(:,index(end));
      else
          left=find(index<inter(i));
          right=find(index>inter(i));
          qc_inter(:,inter(i))=(qc_raw(:,index(left(end)))+qc_raw(:,index(right(1))))/2;
      end
    end
else 
    qc_inter=qc_raw;
end

waitbar(0.2);

    %2. average(batch or window)
    % qc_ave is the processed qc data for following steps 
    qc_ave=[];
    col=size(qc_inter,2);
    if (qc_manner==1)% batch; num of qc will be reduced
       for i=1:qc_batch:col
            if((i+qc_batch-1)<=col)
                qc_ave=[qc_ave,mean(qc_inter(:,i:(i+qc_batch-1)),2)];
            else
                qc_ave=[qc_ave,mean(qc_inter(:,i:end),2)];
            end
        end
        
    elseif (qc_manner==2)% mowing window; step=1 and width=qc_batch
        time=floor(col/qc_batch);
        remainder=rem(col,qc_batch);
        for i=1:(col-qc_batch+1)
            qc_ave=[qc_ave,mean(qc_inter(:,i:(i+qc_batch-1)),2)];
        end
        if (remainder)
            for j=time*qc_batch:col
                qc_ave=[qc_ave,mean(qc_inter(:,j:col),2)];  
            end
        end
    end
waitbar(0.3);

    % 3. RSD filter
    % keep variables which rsd_qc_ave<rsd_ratio
    rsd_qc_ave=100*std(qc_ave,0,2)./mean(qc_ave,2);
    figure('Name','histogram of RSD for QCs','NumberTitle','off');
    step=0:10:max(rsd_qc_ave);
    hist(rsd_qc_ave,step);
    h = findobj(gca,'Type','patch');
    set(h,'FaceColor','r','EdgeColor','w')
    xlim([0 max(rsd_qc_ave)]);
    xlabel('RSD(%)');
    ylabel('frequency');
    keep=find(rsd_qc_ave<rsd_ratio);
    sample_rsded=sample(keep',:);
    qc_rsded=qc_ave(keep',:);
    datatxt_rsded=datatxt1(keep',:);
waitbar(0.4);
     
    % 4. zero adjustment
    % keep variables which zero ratio of qc_rsded<zero_ratio
    keepkeep=[];
    for k=1:size(keep,1)
         zero=find(qc_rsded(k,:)==0);
         if (length(zero)/size(qc_rsded,2)<zero_ratio)
             keepkeep=[keepkeep,k];
         end
    end
    qc_zeroed=qc_rsded(keepkeep,:);
    sample_zero=sample_rsded(keepkeep,:);
    datatxt_zero=datatxt_rsded(keepkeep,:);
    
for kk=1:length(keepkeep)
    zero=find(qc_zeroed(kk,:)==0);
    lie=size(qc_zeroed,2);
    nonzero=setdiff(1:lie,zero);
    if(zero)
       qc_zeroed(kk,zero)=mean(qc_zeroed(kk,nonzero),2);
    end
end

qc_ready=qc_zeroed;% qc preparation completed

waitbar(0.5);
% do calibration and scaling based on qc_zeroed and sample_zero


sample_window=ceil(size(sample_zero,2)/size(qc_inter,2));% sample number associate to each QC
sample_batch=sample_window*qc_batch;

if (is)
    sample_ready=[];
%     rsd_is_before=100*std(sample(1,:))/mean(sample(1,:));% rsd before calibration
    for g=1:size(sample_zero,1)
        sample_ready=[sample_ready; 10000*sample_zero(g,:)./sample(1,:)];
    end  
else
    sample_ready=sample_zero;
end

if(qc)
    if (qc_manner==1)% batch;
        timetime=floor(size(sample_ready,2)/sample_batch);
        remain=rem(size(sample_ready,2),sample_batch);
        for p=1:timetime
            for q=(((p-1)*sample_batch)+1):(sample_batch*p)
                sample_ready(:,q)=sample_ready(:,q)./qc_ready(:,p);
            end  
        end
            if(remain)
                for r=(sample_batch*timetime+1):size(sample_ready,2)
                   sample_ready(:,r)=sample_ready(:,r)./qc_ready(:,end);
                end 
            end        
    elseif (qc_manner==2)% window
        timetime=floor(size(sample_ready,2)/sample_window);
        remain=rem(size(sample_ready,2),sample_window);
        for p=1:timetime;
            for q=(((p-1)*sample_window)+1):(sample_window*p)
                sample_ready(:,q)=sample_ready(:,q)./qc_ready(:,p);
            end
        end
        if(remain)
            for r=(sample_window*timetime+1):size(sample_ready,2)
                sample_ready(:,r)=sample_ready(:,r)./qc_ready(:,end);
            end            
        end 
    end 
%     sample_final=sample_ready;
end

if(zscore)
%     sample_z=[];
    for h=1:size(sample_ready,2)
        sample_ready(:,h)=(sample_ready(:,h)-mean(sample_ready(:,h)))./std(sample_ready(:,h));
    end
end

waitbar(0.8);

%  result output: sample_ready and qc_ready

rsd_first_before=100*std(sample(1,:))/mean(sample(1,:));% rsd before calibration (first row)
rsd_first_after=100*std(sample_ready(1,:))/mean(sample_ready(1,:));% rsd after calibration (first row)
delete_rsd=variable-size(keep,1);% deleted because of RSD>rsd_ratio
deleted_zero=size(keep,1)-length(keepkeep);% deleted because of zero>zero_ratio

% % figure
% figure('Name','Calibration result window','NumberTitle','off');

[Fileresult,Pathresult] = uiputfile({'*.xls';'*.xlsx'},'Save the result');
temp=num2cell(sample_ready);
temptemp=[datatxt_zero,temp];
cc=cell(1,1);
cc{1}='Compound';
datatxt2=[cc,datatxt2];
sample_final=[datatxt2;temptemp];% calibrated samples with title and compound names

if(qc)
    if (qc_manner==1)% batch
        qc_name=cell(1,size(qc_ready,2));
        for z=1:size(qc_ready,2)
        qc_name{1,z}=strcat('batch_qc',num2str(z));
        end
              
    elseif (qc_manner==2)% window
        qc_name=cell(1,size(qc_ready,2));
        for z=1:size(qc_ready,2)
        qc_name{1,z}=strcat('window_qc',num2str(z));
        end
    end
   temp1=num2cell(qc_ready);
   qc_final=[qc_name;temp1];% qc with title
else
   qc_final=qc_ready;
end
    
save result sample_final qc_final;% save to mat
% save to file
if(size(sample_final,2)<250)
    xlswrite([Pathresult,Fileresult], sample_final, 'sheet1');
    xlswrite([Pathresult,Fileresult], qc_final, 'sheet2');
else
    csvwrite([Pathresult,Fileresult], sample_ready);
%     csvwrite([Pathresult,Fileresult], qc_ready);
end

waitbar(1);
close(w);
t=toc;
message=strvcat('IS RSD (%) before calibration:  ',num2str(rsd_first_before),...
    'IS RSD (%)after calibration:  ',num2str(rsd_first_after),...
    'number of variables deleted because of large RSD ratio:  ',num2str(delete_rsd),...    
    'number of variables deleted because of large zero ratio:  ',num2str(deleted_zero),...
    'time spend (s):  ',num2str(t));
waitfor(helpdlg(message,'result info'));
msgbox('Calibration finished! please find the reslt in specified folder and file!','help');

% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close(calibration);
delete raw.mat;% data and datatxt
delete qclist.mat;% current or final qc list
delete rawlist.mat;% raw qc list
close all;


% --- Executes on button press in pushbutton7. parameter setting finished
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.uipanel2,'visible','on');%outlier selection
% set(handles.pushbutton4,'visible','on');% run and save result
%% initialization: 2 dimention, sample and QC are all plotted.
load raw;
[row,col]=size(data);
num_qc=str2num(get(handles.edit1,'string'));
% col_sample=str2num(get(handles.edit5,'string'));
qc_list=datatxt(1,(size(datatxt,2)-num_qc+1):end);
rawqc_list=qc_list;
qc=data(:,(col-num_qc+1):end);
% rawnum_qc=num_qc;
index=1:size(qc_list,2);
rawindex=index;
% sample_qc_list=datatxt(1,2:end);
set(handles.listbox1,'string',qc_list');
set(handles.popupmenu1,'value',2);
set(handles.popupmenu2,'value',1);
set(handles.text7,'string',num2str(num_qc));
set(handles.text5,'string','0');
save qclist qc_list num_qc index;% current qc list
save rawlist rawqc_list rawindex;% initial (all) qc list
% type=get(handles.popupmenu1,'string');
% dim=get(handles.popupmenu2,'string');

% [T,P]=pca(data',2);
[T,P]=pca(qc',2);
cla;
hold(handles.axes1,'on');
% plot(handles.axes1,T(1:col_sample,1),T(1:col_sample,2),'bs','markersize',8);% sample
% hold on
plot(handles.axes1,T(:,1),T(:,2),'ro','markersize',8);   % qc
xlabel('t1');
ylabel('t2');
% hold on
% s=std(T)*3+mean(T);
% ss=mean(T)-3*std(T);
% line(1:col,s,'Color','r','LineWidth',50);
% line(1:col,ss,'Color','r','LineWidth',50);
hold(handles.axes1,'off');

set(handles.text7,'string',num2str(num_qc));
set(handles.text5,'string','0');




function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double


% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




% --- Executes on button press in pushbutton9.% include
function pushbutton9_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
load qclist;
load rawlist;
S=get(handles.listbox1,'Value');% which one(s) is/are selected
index=unique([index,S]);
qc_list=rawqc_list(index);
num_qc=length(index);
save qclist qc_list num_qc index;% update qclist
% num_qc=str2num(get(handles.text7,'String'));
set(handles.text5,'string',num2str(length(rawindex)-num_qc));

%  set listbox
for i=1:length(index)
    rawqc_list(index(i))=strcat(rawqc_list(index(i)),'[in]')';
end
out=setdiff(rawindex,index);
for i=1:length(out)
    rawqc_list(out(i))=strcat(rawqc_list(out(i)),'[out]')';
end
set(handles.listbox1,'string',rawqc_list);

% update figure
type=get(handles.popupmenu1,'Value');
dim=get(handles.popupmenu2,'Value');
load raw; % data and datatxt
% load qclist; % qc_list, num_qc, and index
[row,col]=size(data);
% num_qc=get(handles.edit1,'string');
% num_qc1=str2num(num_qc);
col_sample=str2num(get(handles.edit5,'string'));
sample=data(:,1:col_sample);
qc=data(:,(col_sample+index));
data1=[sample qc];
cla;
% qc_list=datatxt(1,(size(datatxt,2)-num_qc1)+1):end);
% sample_qc_list=datatxt(1,2:end);
% sample_list=datatxt(1,2:col_sample);
% set(handles.listbox1,'string',qc_list');
if (type==1) % both sample and qc
    if (dim==1)% 2 dimention
        [T,P]=pca(data1',2);
        hold(handles.axes1,'on');
        plot(handles.axes1,T(1:col_sample,1),T(1:col_sample,2),'bs','markersize',8);% sample
        hold on
        plot(handles.axes1,T((col_sample+1):end,1),T((col_sample+1):end,2),'ro','markersize',8);   % qc
        xlabel('t1');
        ylabel('t2');
        hold(handles.axes1,'off');
    elseif(dim==2)% 1 dimention
        [T,P]=pca(data1',1);
        hold(handles.axes1,'on');
        plot(handles.axes1,1:col_sample,T(1:col_sample,1),'bs','markersize',8);% sample
        hold on
        plot(handles.axes1,(col_sample+1):size(T,1),T((col_sample+1):end,1),'ro','markersize',8);   % qc
        hold on
        s=std(T)*3+mean(T);
        ss=mean(T)-3*std(T);
        line(1:col,s,'Color','r','LineWidth',50);
        line(1:col,ss,'Color','r','LineWidth',50);
        xlabel('index');
        ylabel('t1');
        hold(handles.axes1,'off');
    end
elseif (type ==2)%qc only
    if (dim==1)% 2 dimention
        [T_qc,P_qc]=pca(qc',2);
        hold(handles.axes1,'on');
        plot(handles.axes1,T_qc(:,1),T_qc(:,2),'ro','markersize',8);   % qc
        xlabel('t1');
        ylabel('t2');
        hold(handles.axes1,'off');
    elseif(dim==2)% 1 dimention
        [T_qc,P_qc]=pca(qc',1);
        hold(handles.axes1,'on');
        plot(handles.axes1,1:num_qc,T_qc(:,1),'ro','markersize',8);   % qc
        hold on
        s=std(T_qc)*3+mean(T_qc);
        ss=mean(T_qc)-3*std(T_qc);
        line(1:0.1:num_qc,s,'Color','r','LineWidth',50);
        line(1:0.1:num_qc,ss,'Color','r','LineWidth',50);
        xlabel('index');
        ylabel('t1');
        hold(handles.axes1,'off');
    end
end



% --- Executes on button press in pushbutton10.% exclude
function pushbutton10_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
load qclist;
load rawlist;
S=get(handles.listbox1,'Value');% which one(s) is/are selected
index=setdiff(index,S);
qc_list=rawqc_list(index);
num_qc=length(index);
save qclist qc_list num_qc index;% update qclist
% num_qc=str2num(get(handles.text7,'String'));
set(handles.text5,'string',num2str(length(rawindex)-num_qc));

%  set listbox
for i=1:length(index)
    rawqc_list(index(i))=strcat(rawqc_list(index(i)),'[in]')';
end
out=setdiff(rawindex,index);
for i=1:length(out)
    rawqc_list(out(i))=strcat(rawqc_list(out(i)),'[out]')';
end
set(handles.listbox1,'string',rawqc_list);

% update figure
type=get(handles.popupmenu1,'Value');
dim=get(handles.popupmenu2,'Value');
load raw; % data and datatxt
% load qclist; % qc_list, num_qc, and index
[row,col]=size(data);
% num_qc=get(handles.edit1,'string');
% num_qc1=str2num(num_qc);
col_sample=str2num(get(handles.edit5,'string'));
sample=data(:,1:col_sample);
qc=data(:,(col_sample+index));
data1=[sample qc];
cla;
% qc_list=datatxt(1,(size(datatxt,2)-num_qc1)+1):end);
% sample_qc_list=datatxt(1,2:end);
% sample_list=datatxt(1,2:col_sample);
% set(handles.listbox1,'string',qc_list');
if (type==1) % both sample and qc
    if (dim==1)% 2 dimention
        [T,P]=pca(data1',2);
        hold(handles.axes1,'on');
        plot(handles.axes1,T(1:col_sample,1),T(1:col_sample,2),'bs','markersize',8);% sample
        hold on
        plot(handles.axes1,T((col_sample+1):end,1),T((col_sample+1):end,2),'ro','markersize',8);   % qc
        xlabel('t1');
        ylabel('t2');
        hold(handles.axes1,'off');
    elseif(dim==2)% 1 dimention
        [T,P]=pca(data1',1);
        hold(handles.axes1,'on');
        plot(handles.axes1,1:col_sample,T(1:col_sample,1),'bs','markersize',8);% sample
        hold on
        plot(handles.axes1,(col_sample+1):size(T,1),T((col_sample+1):end,1),'ro','markersize',8);   % qc
        hold on
        s=std(T)*3+mean(T);
        ss=mean(T)-3*std(T);
        line(1:col,s,'Color','r','LineWidth',50);
        line(1:col,ss,'Color','r','LineWidth',50);
        xlabel('index');
        ylabel('t1');
        hold(handles.axes1,'off');
    end
elseif (type ==2)%qc only
    if (dim==1)% 2 dimention
        [T_qc,P_qc]=pca(qc',2);
        hold(handles.axes1,'on');
        plot(handles.axes1,T_qc(:,1),T_qc(:,2),'ro','markersize',8);   % qc
        xlabel('t1');
        ylabel('t2');
        hold(handles.axes1,'off');
    elseif(dim==2)% 1 dimention
        [T_qc,P_qc]=pca(qc',1);
        hold(handles.axes1,'on');
        plot(handles.axes1,1:num_qc,T_qc(:,1),'ro','markersize',8);   % qc
        hold on
        s=std(T_qc)*3+mean(T_qc);
        ss=mean(T_qc)-3*std(T_qc);
        line(1:0.1:num_qc,s,'Color','r','LineWidth',50);
        line(1:0.1:num_qc,ss,'Color','r','LineWidth',50);
        xlabel('index');
        ylabel('t1');
        hold(handles.axes1,'off');
    end
end



% --- Executes on button press in pushbutton11.
function pushbutton11_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% waitfor(msgbox('to be completed! select manually please!','Auto selection','help'));
load rawlist;% rawqc_list rawindex
load raw; % data and datatxt

% update figure and parameters
col_sample=str2num(get(handles.edit5,'string'));
num_qc=str2num(get(handles.edit1,'string'));
qc=data(:,(end-num_qc+1):end);

cla;
[T,P]=pca(qc',1);
s=std(T)*3+mean(T);
ss=mean(T)-3*std(T);
outlier=find(or(T>s,T<ss))% auto select

hold(handles.axes1,'on');
plot(handles.axes1,1:num_qc,T(:,1),'ro','markersize',8);   % qc
hold on
plot(handles.axes1,outlier',T(outlier',1),'ko','markersize',20);   % qc
line(1:num_qc,s,'Color','r','LineWidth',50);
line(1:num_qc,ss,'Color','r','LineWidth',50);
xlabel('index');
ylabel('t1');
hold(handles.axes1,'off');

index=setdiff(rawindex,outlier');
qc_list=rawqc_list(index);
num_qc=length(index);
save qclist qc_list num_qc index;

%  set listbox
for i=1:length(index)
    rawqc_list(index(i))=strcat(rawqc_list(index(i)),'[in]')';
end
for i=1:size(outlier,1)
    rawqc_list(outlier(i))=strcat(rawqc_list(outlier(i,1)),'[out]')';
end
set(handles.listbox1,'string',rawqc_list);

% set other uicontrols
set(handles.popupmenu1,'Value',2);% qcs only
set(handles.popupmenu2,'Value',2);% 1 dimention
set(handles.text5,'string',num2str(size(outlier,1)));

message=strvcat('out: | t1| > 3*SD ','number of qc outlier(s):  ',num2str(size(outlier,1)));
msgbox(message,'result of auto selection');

% --- Executes on button press in pushbutton12.
function pushbutton12_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.pushbutton4,'visible','on');% run and save result



% --- Executes on selection change in popupmenu3.
function popupmenu3_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu3 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu3


% --- Executes during object creation, after setting all properties.
function popupmenu3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on mouse press over axes background. uncompleted
function axes1_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
hh=get(handles.axes1,'children');
type=get(handles.popupmenu1,'Value');
dim=get(handles.popupmenu2,'Value');

    if(type==1) % both sample and qc        
         t1=get(hh(end-1),'XData');% hh(end-1)=qc handel; hh(end)= sample handle; others are for the line
         t2=get(hh(end-1),'YData');
    end    
         
p=get(handles.axes1,'CurrentPoint') ;
x = p(1,1);
y = p(1,2);




