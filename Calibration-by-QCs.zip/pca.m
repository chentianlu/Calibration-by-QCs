function [t,p]=pca(X,comp);

%
%   [t,p]=pca(X,comp);
%
%   Calculates Principal componets of X by calc eigvectors of X'*X or X*X' 
%   Depending on whats easiest to calculate....
%


[N,K]=size(X);

if N<K
    [C,D]=eig(X*X'); 
    XP=X'; 
    for i=1:comp 
        t=C(:,min(find(diag(D)==max(max(D)))));  
        D(find(max(max(D))==D))=0;
        p(:,i)=XP*t; 
        p(:,i)=p(:,i)/norm(p(:,i)); 
    end; 
    t=X*p; 
else
%% added by ctl 20130523
temp=X'*X;
temp(:,end)=1;
temp(end,:)=1;
[C,D]=eig(temp); 
%% end of adding
% [C,D]=eig(X'*X); % comment by ctl 20130523
    for i=1:comp
        p(:,i)=C(:,min(find(diag(D)==max(max(D)))));  
        D(min(find(max(max(D))==D)))=0; 
        p(:,i)=p(:,i)/norm(p(:,i)); 
    end; 
    t=X*p;
end
